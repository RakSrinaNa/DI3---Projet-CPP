#ifndef PROJETGRAPH_CGRAPHTOOLBOXUNIT_H
#define PROJETGRAPH_CGRAPHTOOLBOXUNIT_H

class CGraphToolboxUnit
{
public:
	static void GRTUnitTests();
};

#endif
