#ifndef CARCUNIT
#define CARCUNIT

class CArcUnit
{
public:
	static void ARCUnitTests();
};

#endif