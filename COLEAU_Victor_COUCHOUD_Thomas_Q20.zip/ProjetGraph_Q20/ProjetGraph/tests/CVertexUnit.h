#ifndef PROJETGRAPH_CVERTEXUNIT_H
#define PROJETGRAPH_CVERTEXUNIT_H

class CVertexUnit
{
public:
	static void VERUnitTest();
	
private:
	static void VERUnitTestConstructorGetSet();
	
	static void VERUnitTestArcIn();
	
	static void VERUnitTestArcOut();
	
	static void VERUnitTestOperators();
};

#endif
