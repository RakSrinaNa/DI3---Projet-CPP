#ifndef PROJETGRAPH_CGRAPHUNIT_H
#define PROJETGRAPH_CGRAPHUNIT_H

class CGraphUnit
{
public:
	static void GRAUnitTests();

private:
	static void GRAUnitTestVertices();
	
	static void GRAUnitTestArcs();
	
	static void GRAUnitTestCopy();
	
	static void GRAUnitTestReadFromFile();
};

#endif
