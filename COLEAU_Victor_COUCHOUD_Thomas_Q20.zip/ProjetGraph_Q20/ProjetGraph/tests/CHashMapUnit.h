#ifndef PROJETGRAPH_CHASHMAPUNIT_H
#define PROJETGRAPH_CHASHMAPUNIT_H

class CHashMapUnit
{
public:
	static void HMPUnitTest();
};

#endif
