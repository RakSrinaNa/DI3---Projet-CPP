#ifndef PREOJET3MATRICE_CMATRIXUNIT_H
#define PREOJET3MATRICE_CMATRIXUNIT_H

class CMatrixUnit
{
public:
	static void MTXUnitTests();
	
private:
	static void MTXUnitTestGetSet();
	static void MTXUnitTestConstructors();
	static void MTXUnitTestOperations();
};

#endif
