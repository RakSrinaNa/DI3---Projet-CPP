#ifndef PREOJETMATRICE_CSQUAREMATRIXUNIT_H
#define PREOJETMATRICE_CSQUAREMATRIXUNIT_H

class CSquareMatrixUnit
{
public:
	static void SMXUnitTests();

private:
	static void SMXUnitTestGetSet();
	static void SMXUnitTestConstructors();
	static void SMXUnitTestOperations();
};

#endif
