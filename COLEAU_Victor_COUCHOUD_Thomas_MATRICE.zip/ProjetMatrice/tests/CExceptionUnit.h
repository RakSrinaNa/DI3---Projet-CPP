#ifndef PREOJET3MATRICE_CEXCEPTIONUNIT_H
#define PREOJET3MATRICE_CEXCEPTIONUNIT_H

class CExceptionUnit
{
public:
	static void EXUnitTests();
	
private:
	static void EXUnitTestID();
	static void EXUnitTestMessage();
};

#endif
