#ifndef PREOJET3MATRICE_CMATRIXPARSERUNIT_H
#define PREOJET3MATRICE_CMATRIXPARSERUNIT_H

class CMatrixParserUnit
{
public:
	static void MTXPUnitTests();
};

#endif
