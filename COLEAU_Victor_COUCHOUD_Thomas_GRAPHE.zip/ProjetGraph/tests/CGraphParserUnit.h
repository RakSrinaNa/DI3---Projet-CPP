#ifndef PROJETGRAPH_CGRAPHPARSERUNIT_H
#define PROJETGRAPH_CGRAPHPARSERUNIT_H

class CGraphParserUnit
{
public:
	static void PGRAUnitTests();
};

#endif
